# Vegetables_detector_annotation > 2024-08-01 3:58pm
https://universe.roboflow.com/lettucedetector/vegetables_detector_annotation

Provided by a Roboflow user
License: CC BY 4.0

